import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TicTacToeGUI extends JFrame implements ActionListener {
    private JButton[][] buttons = new JButton[3][3];
    private char player = 'X', opponent = 'O';
    private boolean playerTurn = true; // Human plays 'O', AI plays 'X'

    public TicTacToeGUI() {
        setTitle("Tic Tac Toe with AI");
        setSize(400, 400);
        setLayout(new GridLayout(3, 3));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Font font = new Font("Arial", Font.BOLD, 60);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new JButton("");
                buttons[i][j].setFont(font);
                buttons[i][j].setFocusPainted(false);
                buttons[i][j].addActionListener(this);
                add(buttons[i][j]);
            }
        }
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton btn = (JButton) e.getSource();

        if (btn.getText().equals("") && playerTurn) {
            btn.setText(String.valueOf(opponent)); // Human = O
            playerTurn = false;

            if (!isMovesLeft(getBoard())) {
                JOptionPane.showMessageDialog(this, "Draw!");
                resetBoard();
                return;
            }

            int[] bestMove = findBestMove(getBoard());
            buttons[bestMove[0]][bestMove[1]].setText(String.valueOf(player));
            playerTurn = true;

            int score = evaluate(getBoard());
            if (score == 10) {
                JOptionPane.showMessageDialog(this, "AI Wins!");
                resetBoard();
            } else if (score == -10) {
                JOptionPane.showMessageDialog(this, "You Win!");
                resetBoard();
            }
        }
    }

    private void resetBoard() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                buttons[i][j].setText("");
    }

    private char[][] getBoard() {
        char[][] board = new char[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String text = buttons[i][j].getText();
                board[i][j] = text.equals("") ? '_' : text.charAt(0);
            }
        }
        return board;
    }

    // --- AI Functions (same as your console version) ---
    static boolean isMovesLeft(char board[][]) {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board[i][j] == '_')
                    return true;
        return false;
    }

    static int evaluate(char b[][]) {
        for (int row = 0; row < 3; row++) {
            if (b[row][0] == b[row][1] && b[row][1] == b[row][2]) {
                if (b[row][0] == 'X') return +10;
                else if (b[row][0] == 'O') return -10;
            }
        }
        for (int col = 0; col < 3; col++) {
            if (b[0][col] == b[1][col] && b[1][col] == b[2][col]) {
                if (b[0][col] == 'X') return +10;
                else if (b[0][col] == 'O') return -10;
            }
        }
        if (b[0][0] == b[1][1] && b[1][1] == b[2][2]) {
            if (b[0][0] == 'X') return +10;
            else if (b[0][0] == 'O') return -10;
        }
        if (b[0][2] == b[1][1] && b[1][1] == b[2][0]) {
            if (b[0][2] == 'X') return +10;
            else if (b[0][2] == 'O') return -10;
        }
        return 0;
    }

    static int minimax(char board[][], int depth, boolean isMax) {
        int score = evaluate(board);

        if (score == 10) return score - depth;
        if (score == -10) return score + depth;
        if (!isMovesLeft(board)) return 0;

        if (isMax) {
            int best = -1000;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (board[i][j] == '_') {
                        board[i][j] = 'X';
                        best = Math.max(best, minimax(board, depth + 1, false));
                        board[i][j] = '_';
                    }
                }
            }
            return best;
        } else {
            int best = 1000;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (board[i][j] == '_') {
                        board[i][j] = 'O';
                        best = Math.min(best, minimax(board, depth + 1, true));
                        board[i][j] = '_';
                    }
                }
            }
            return best;
        }
    }

    static int[] findBestMove(char board[][]) {
        int bestVal = -1000;
        int[] bestMove = {-1, -1};

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == '_') {
                    board[i][j] = 'X';
                    int moveVal = minimax(board, 0, false);
                    board[i][j] = '_';
                    if (moveVal > bestVal) {
                        bestMove[0] = i;
                        bestMove[1] = j;
                        bestVal = moveVal;
                    }
                }
            }
        }
        return bestMove;
    }

    public static void main(String[] args) {
        new TicTacToeGUI();
    }
}
