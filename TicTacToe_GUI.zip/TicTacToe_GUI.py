import tkinter as tk
from tkinter import ttk, messagebox
import random
import math
import time
from copy import deepcopy
from functools import lru_cache

EMPTY = ' '
PLAYERS = ['X', 'O']
WIN_LINES = [
    (0,1,2),(3,4,5),(6,7,8),
    (0,3,6),(1,4,7),(2,5,8),
    (0,4,8),(2,4,6)
]

def check_winner(board):
    for a,b,c in WIN_LINES:
        if board[a] != EMPTY and board[a] == board[b] == board[c]:
            return board[a]
    if EMPTY not in board:
        return 'Draw'
    return None

def available_moves(board):
    return [i for i, v in enumerate(board) if v == EMPTY]

def other(player):
    return 'O' if player == 'X' else 'X'

def minimax(board, player, ai_player):
    winner = check_winner(board)
    if winner is not None:
        if winner == 'Draw':
            return 0, None
        return (1 if winner == ai_player else -1), None
    moves = available_moves(board)
    best_move = None
    if player == ai_player:
        best_score = -2
        for m in moves:
            board[m] = player
            score, _ = minimax(board, other(player), ai_player)
            board[m] = EMPTY
            if score > best_score:
                best_score = score
                best_move = m
                if best_score == 1:
                    break
        return best_score, best_move
    else:
        best_score = 2
        for m in moves:
            board[m] = player
            score, _ = minimax(board, other(player), ai_player)
            board[m] = EMPTY
            if score < best_score:
                best_score = score
                best_move = m
                if best_score == -1:
                    break
        return best_score, best_move

def alphabeta(board, player, ai_player, alpha=-2, beta=2):
    winner = check_winner(board)
    if winner is not None:
        if winner == 'Draw':
            return 0, None
        return (1 if winner == ai_player else -1), None
    moves = available_moves(board)
    best_move = None
    if player == ai_player:
        value = -2
        for m in moves:
            board[m] = player
            score, _ = alphabeta(board, other(player), ai_player, alpha, beta)
            board[m] = EMPTY
            if score > value:
                value = score
                best_move = m
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return value, best_move
    else:
        value = 2
        for m in moves:
            board[m] = player
            score, _ = alphabeta(board, other(player), ai_player, alpha, beta)
            board[m] = EMPTY
            if score < value:
                value = score
                best_move = m
            beta = min(beta, value)
            if alpha >= beta:
                break
        return value, best_move

@lru_cache(maxsize=None)
def board_keyed(state_str, player, ai_player):
    board = list(state_str)
    winner = None
    for a,b,c in WIN_LINES:
        if board[a] != EMPTY and board[a] == board[b] == board[c]:
            winner = board[a]
            break
    if winner is not None:
        return (1 if winner == ai_player else -1)
    if EMPTY not in board:
        return 0
    moves = [i for i,v in enumerate(board) if v == EMPTY]
    if player == ai_player:
        best_score = -2
        for m in moves:
            board[m] = player
            score = board_keyed(''.join(board), other(player), ai_player)
            board[m] = EMPTY
            if score > best_score:
                best_score = score
                if best_score == 1:
                    break
        return best_score
    else:
        best_score = 2
        for m in moves:
            board[m] = player
            score = board_keyed(''.join(board), other(player), ai_player)
            board[m] = EMPTY
            if score < best_score:
                best_score = score
                if best_score == -1:
                    break
        return best_score

def full_game_tree_best_move(board, player, ai_player):
    best = None
    moves = available_moves(board)
    if player == ai_player:
        best_score = -2
        for m in moves:
            board[m] = player
            score = board_keyed(''.join(board), other(player), ai_player)
            board[m] = EMPTY
            if score > best_score:
                best_score = score
                best = m
                if best_score == 1:
                    break
        return best_score, best
    else:
        best_score = 2
        for m in moves:
            board[m] = player
            score = board_keyed(''.join(board), other(player), ai_player)
            board[m] = EMPTY
            if score < best_score:
                best_score = score
                best = m
                if best_score == -1:
                    break
        return best_score, best

class MCTSNode:
    def __init__(self, state, player, parent=None, move_from_parent=None):
        self.state = state
        self.player = player
        self.parent = parent
        self.move_from_parent = move_from_parent
        self.children = {}
        self.untried_moves = available_moves(self.state)
        self.wins = 0
        self.visits = 0

    def uct_select_child(self):
        C = math.sqrt(2)
        best = None
        best_score = -1e9
        for m, child in self.children.items():
            if child.visits == 0:
                score = float('inf')
            else:
                score = (child.wins / child.visits) + C * math.sqrt(math.log(self.visits) / child.visits)
            if score > best_score:
                best_score = score
                best = child
        return best

    def expand(self):
        m = self.untried_moves.pop()
        new_state = self.state[:]
        new_state[m] = self.player
        node = MCTSNode(new_state, other(self.player), parent=self, move_from_parent=m)
        self.children[m] = node
        return node

    def update(self, result, ai_player):
        self.visits += 1
        if result == ai_player:
            self.wins += 1
        elif result == 'Draw':
            self.wins += 0.5

def mcts_best_move(root_state, player_to_move, ai_player, iterations=800, time_limit=None):
    root = MCTSNode(root_state[:], player_to_move)
    start = time.time()
    it = 0
    while it < iterations:
        it += 1
        node = root
        state = node.state[:]
        while node.untried_moves == [] and node.children:
            node = node.uct_select_child()
            state = node.state[:]
        if node.untried_moves:
            node = node.expand()
            state = node.state[:]
        winner = check_winner(state)
        current_player = node.player
        while winner is None:
            moves = available_moves(state)
            m = random.choice(moves)
            state[m] = current_player
            current_player = other(current_player)
            winner = check_winner(state)
        result = winner
        while node is not None:
            node.update(result, ai_player)
            node = node.parent
        if time_limit and (time.time() - start) > time_limit:
            break
    best_move = None
    best_visits = -1
    for m, child in root.children.items():
        if child.visits > best_visits:
            best_visits = child.visits
            best_move = m
    return best_move

class TicTacToeGUI:
    def __init__(self, master):
        self.master = master
        master.title('Tic-Tac-Toe — Minimax / AlphaBeta / MCTS / Game Tree')
        self.board = [EMPTY]*9
        self.buttons = []
        self.ai_engine = tk.StringVar(value='Minimax')
        self.ai_player = tk.StringVar(value='O')
        self.starting = tk.StringVar(value='Human')
        self.mcts_iters = tk.IntVar(value=800)
        self.create_widgets()
        self.game_over = False
        self.current_player = 'X'

    def create_widgets(self):
        frame = ttk.Frame(self.master, padding=10)
        frame.grid(row=0, column=0)
        board_frame = ttk.Frame(frame)
        board_frame.grid(row=0, column=0, rowspan=4)
        for i in range(9):
            b = tk.Button(board_frame, text=' ', font=('Helvetica', 28), width=4, height=2,
                          command=lambda i=i: self.on_click(i))
            b.grid(row=i//3, column=i%3)
            self.buttons.append(b)
        control_frame = ttk.Frame(frame, padding=(10,0,0,0))
        control_frame.grid(row=0, column=1, sticky='N')
        ttk.Label(control_frame, text='AI Engine:').grid(row=0, column=0, sticky='w')
        engine_menu = ttk.OptionMenu(control_frame, self.ai_engine, 'Minimax', 'Minimax', 'Alpha-Beta', 'MCTS', 'Full Game Tree')
        engine_menu.grid(row=1, column=0, sticky='w')
        ttk.Label(control_frame, text='AI Symbol:').grid(row=2, column=0, sticky='w')
        ttk.OptionMenu(control_frame, self.ai_player, 'O', 'X', 'O').grid(row=3, column=0, sticky='w')
        ttk.Label(control_frame, text='Who starts:').grid(row=4, column=0, sticky='w')
        ttk.OptionMenu(control_frame, self.starting, 'Human', 'Human', 'AI').grid(row=5, column=0, sticky='w')
        ttk.Label(control_frame, text='MCTS Iterations:').grid(row=6, column=0, sticky='w')
        ttk.Spinbox(control_frame, from_=10, to=5000, increment=10, textvariable=self.mcts_iters).grid(row=7, column=0, sticky='w')
        ttk.Button(control_frame, text='Play / Reset', command=self.reset).grid(row=8, column=0, pady=(10,0))
        self.status = ttk.Label(frame, text='Welcome! Choose settings and press Play / Reset', padding=(10,5))
        self.status.grid(row=4, column=0, columnspan=2)

    def on_click(self, idx):
        if self.game_over:
            return
        if self.board[idx] != EMPTY:
            return
        if self.current_player == self.ai_player.get():
            return
        self.make_move(idx)
        winner = check_winner(self.board)
        if winner:
            self.end_game(winner)
            return
        self.master.after(200, self.ai_move_if_needed)

    def make_move(self, idx):
        self.board[idx] = self.current_player
        self.buttons[idx].config(teDAAxt=self.current_player, state='disabled')
        self.current_player = other(self.current_player)

    def ai_move_if_needed(self):
        if self.game_over:
            return
        if self.current_player != self.ai_player.get():
            return
        engine = self.ai_engine.get()
        ai = self.ai_player.get()
        move = None
        start = time.time()
        if engine == 'Minimax':
            _, move = minimax(self.board, self.current_player, ai)
        elif engine == 'Alpha-Beta':
            _, move = alphabeta(self.board, self.current_player, ai)
        elif engine == 'Full Game Tree':
            _, move = full_game_tree_best_move(self.board, self.current_player, ai)
        elif engine == 'MCTS':
            iters = max(10, self.mcts_iters.get())
            move = mcts_best_move(self.board, self.current_player, ai, iterations=iters)
        if move is None:
            moves = available_moves(self.board)
            move = random.choice(moves) if moves else None
        if move is not None:
            self.make_move(move)
        elapsed = time.time() - start
        winner = check_winner(self.board)
        if winner:
            self.end_game(winner)

    def end_game(self, winner):
        self.game_over = True
        if winner == 'Draw':
            self.status.config(text='Draw!')
            messagebox.showinfo('Game Over', 'Draw!')
        else:
            self.status.config(text=f'{winner} wins!')
            messagebox.showinfo('Game Over', f'{winner} wins!')

    def reset(self):
        for i in range(9):
            self.board[i] = EMPTY
            self.buttons[i].config(text=' ', state='normal')
        self.game_over = False

        # Correctly set who starts
        if self.starting.get() == 'Human':
            self.current_player = other(self.ai_player.get())
        else:
            self.current_player = self.ai_player.get()
            self.master.after(200, self.ai_move_if_needed)

        self.status.config(text='New game — good luck!')

if __name__ == '__main__':
    root = tk.Tk()
    app = TicTacToeGUI(root)
    root.mainloop()
